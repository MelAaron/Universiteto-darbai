package edu.ktu.ds.lab3.utils;

public enum HashType {

    DIVISION,
    MULTIPLICATION,
    JCF7, //Java Collections Framework 7 
    JCF8  //Java Collections Framework 8/11
}
